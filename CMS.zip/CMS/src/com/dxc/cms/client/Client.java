package com.dxc.cms.client;
import java.sql.Connection;
import java.sql.SQLException;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import com.dxc.cms.dbcon.Myconnection;


public class Client {

	public static void main(String[] args) throws SQLException,ClassNotFoundException {
		Scanner scanner = new Scanner(System.in);
		Connection con = Myconnection.getDBConnection();

		while (true) {

			System.out.println("MAIN MENU");
			System.out.println("1. Add Product");
			System.out.println("2. Delete Product");
			System.out.println("3. Update Product");
			System.out.println("4. Find Product by Id");
			System.out.println("5. Find All Products ");
			System.out.println("6. E X I T");
			System.out.print("Please enter your choice (1-6)");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Adding Products : ");
				break;
			case 2:
				System.out.println("Deleting Products : ");
				break;
			case 3:
				System.out.println("Updating Products : ");
				break;
			case 4:
				System.out.println("Finding Products by id : ");
				break;
			case 5:
				System.out.println("Displaying all the  Products : ");
				
				Statement statement= con.createStatement();
				ResultSet res=statement.executeQuery("select * from hr.product" );
				//checking results
				while(res.next()) {
					System.out.print(res.getString(1)+" ");
					System.out.print(res.getString(2)+" ");
					System.out.print(res.getString(3)+" ");
					System.out.println(res.getString(4));
				}
				break;
			case 6:
				System.out.println("Thanks for using my program");
				System.exit(0);
			default:
				System.out.println("Incorrect Option . Please select (1-6)");
			}
		}
	}
}
