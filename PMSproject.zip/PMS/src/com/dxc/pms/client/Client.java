package com.dxc.pms.client;

import com.dxc.pms.model.Product;

public class Client {

	public static void main(String[] args) {
		Product product =new Product(15,"laptop",12,1200000);
		 product.setQuantityonhand(19);
		 
		 System.out.println("product details:");
		System.out.println(product.getProductName());
	}
}
