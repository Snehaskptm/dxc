package com.dxc.pms.model;

public class Product {
	private int ptroductid;
	private String productName;
	private int quantityonhand;
	private  int price;
	public Product() {
		// TODO Auto-generated constructor stub
	}
	public Product(int ptroductid, String productName, int quantityonhand, int price) {
		super();
		this.ptroductid = ptroductid;
		this.productName = productName;
		this.quantityonhand = quantityonhand;
		this.price = price;
	}
	public int getPtroductid() {
		return ptroductid;
	}
	public void setPtroductid(int ptroductid) {
		this.ptroductid = ptroductid;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getQuantityonhand() {
		return quantityonhand;
	}
	public void setQuantityonhand(int quantityonhand) {
		this.quantityonhand = quantityonhand;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + price;
		result = prime * result + ((productName == null) ? 0 : productName.hashCode());
		result = prime * result + ptroductid;
		result = prime * result + quantityonhand;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (price != other.price)
			return false;
		if (productName == null) {
			if (other.productName != null)
				return false;
		} else if (!productName.equals(other.productName))
			return false;
		if (ptroductid != other.ptroductid)
			return false;
		if (quantityonhand != other.quantityonhand)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Product [ptroductid=" + ptroductid + ", productName=" + productName + ", quantityonhand="
				+ quantityonhand + ", price=" + price + "]";
	}
	
	
}
