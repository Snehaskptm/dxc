package com.dxc.cms.client;
import java.sql.Connection;
import java.sql.SQLException;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import com.dxc.cms.dbcon.Myconnection;


public class Client {

	public static void main(String[] args) throws SQLException,ClassNotFoundException {
		Scanner scanner = new Scanner(System.in);
		Connection con = Myconnection.getDBConnection();

		while (true) {

            System.out.println("\nMAIN MENU");
            System.out.println("1. Add Customer");
            System.out.println("2. Delete Customer");
            System.out.println("3. Update Customer");
            System.out.println("4. Find Customer by Id");
            System.out.println("5. Find All Customer ");
            System.out.println("6. E X I T");
            System.out.print("\nPlease enter your choice (1-6) : ");
            
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Adding customer : ");
				break;
			case 2:
				System.out.println("Deleting customer : ");
				break;
			case 3:
				System.out.println("Updating customer : ");
				break;
			case 4:
				System.out.println("Finding customers by id : ");
				break;
			case 5:
				displayCustomer(con);
				break;
			case 6:
				System.out.println("Thanks for using my program");
				System.exit(0);
			default:
				System.out.println("Incorrect Option . Please select (1-6)");
			}
		}
	}

	private static void displayCustomer(Connection con) throws SQLException {
		System.out.println("Displaying all the  customer : ");
		
		Statement statement= con.createStatement();
		ResultSet res=statement.executeQuery("select * from hr.customer" );
		//checking results
		while(res.next()) {
			System.out.print(res.getString(1)+" ");
			System.out.print(res.getString(2)+" ");
			System.out.print(res.getString(3)+" ");
			System.out.println(res.getString(4));
		}
	}
}
