package com.dxc.cms.model;

public class Customer {
	private int customerId;
	private String customerName;
	private int customerAddress;
	private  int billAmount;
	public Customer() {
		// TODO Auto-generated constructor stub
	}
	public Customer(int ptroductid, String productName, int quantityonhand, int price) {
		super();
		this.customerId = ptroductid;
		this.customerName = productName;
		this.customerAddress = quantityonhand;
		this.billAmount = price;
	}
	public int getPtroductid() {
		return customerId;
	}
	public void setPtroductid(int ptroductid) {
		this.customerId = ptroductid;
	}
	public String getProductName() {
		return customerName;
	}
	public void setProductName(String productName) {
		this.customerName = productName;
	}
	public int getQuantityonhand() {
		return customerAddress;
	}
	public void setQuantityonhand(int quantityonhand) {
		this.customerAddress = quantityonhand;
	}
	public int getPrice() {
		return billAmount;
	}
	public void setPrice(int price) {
		this.billAmount = price;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + billAmount;
		result = prime * result + ((customerName == null) ? 0 : customerName.hashCode());
		result = prime * result + customerId;
		result = prime * result + customerAddress;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (billAmount != other.billAmount)
			return false;
		if (customerName == null) {
			if (other.customerName != null)
				return false;
		} else if (!customerName.equals(other.customerName))
			return false;
		if (customerId != other.customerId)
			return false;
		if (customerAddress != other.customerAddress)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Product [ptroductid=" + customerId + ", productName=" + customerName + ", quantityonhand="
				+ customerAddress + ", price=" + billAmount + "]";
	}
	
	
}
